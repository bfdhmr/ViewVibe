#include "sdlaudiowrite.h"

SDLAudioWrite::SDLAudioWrite(QObject *parent) : QObject(parent)
{
    //解码器初始化
    int err;
    decoder = opus_decoder_create(48000, 1, &err);
    //设置音频
    SDL_AudioSpec wantedSpec;
    SDL_AudioSpec obtainedSpec;
    SDL_zero(wantedSpec);
    wantedSpec.freq = 48000;
    wantedSpec.format = AUDIO_S16LSB;
    wantedSpec.channels = 1;
    wantedSpec.samples = 960;
    wantedSpec.callback = audioCallback;
    wantedSpec.userdata = this; //回调函数传参
    //打开设备
    // 打开播放设备 第一个为空意味着 默认设备 , 第二个为 0 表示播放
    dev = SDL_OpenAudioDevice(NULL, 0, &wantedSpec, &obtainedSpec, 0);
    if (dev == 0) {
        qDebug() << "Failed to open audio device: " << SDL_GetError() ;
        SDL_Quit();
        return ;
    }
    //默认播放
    slot_openAudio();
}

void SDLAudioWrite::slot_playAudioFrame(QByteArray recvBuffer)
{
    if( !m_isOpen ) return;
    std::lock_guard<std::mutex> lck( m_mutex );
    m_audioQueue.emplace_back ( recvBuffer );
}


SDLAudioWrite::~SDLAudioWrite()
{
    //回收 销毁编码器
    opus_decoder_destroy(decoder);
    // 停止播放音频
    SDL_PauseAudioDevice(dev, 1);
    // 关闭音频设备和 SDL
    SDL_CloseAudio();
    SDL_Quit();
}

void SDLAudioWrite::audioCallback(void *userdata, Uint8 *stream, int len)
{
    SDLAudioWrite * audio = (SDLAudioWrite *)userdata;
    memset( stream , 0 , len );
    if( !audio->m_audioQueue.empty() )
    {
        QByteArray recvBuffer = audio->m_audioQueue.front();
        {
            std::lock_guard<std::mutex> lck( audio->m_mutex );
            audio->m_audioQueue.pop_front();
        }
        //先解码
        opus_int16 decodedData[4096];
        int frameSizeDecoded = opus_decode(audio->decoder, (const uchar*)recvBuffer.data(),
                                           recvBuffer.size(), decodedData,sizeof(decodedData)/sizeof(decodedData[0]), 0);
        if (frameSizeDecoded < 0) {
            return;
        }
        //解码函数 opus_decode 第一个参数 解码器 第二个参数要解码的缓冲区, 第三参数缓冲区大小, 第四参数输出的缓冲区, 第五参数缓冲区大小, 第六参数选项, 默认值, 表示内容丢失也要解码
        //再混音
        //SDL_MixAudioFormat( stream , (uint8_t*)recvBuffer.data() , AUDIO_S16LSB , recvBuffer.size() , 100);
        SDL_MixAudioFormat( stream , (uint8_t*)decodedData , AUDIO_S16LSB , frameSizeDecoded*sizeof(opus_int16) , 100);
    }
}
