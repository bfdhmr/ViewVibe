#ifndef AUDIOWORLD_H
#define AUDIOWORLD_H

#include <QDebug>
#include <QByteArray>

extern "C"{
#include<SDL.h>
#include <opus/opus.h>
}

//webrtc vad静音检测
#define USE_VAD (1)
#include "WebRtc_Vad/webrtc_vad.h"
enum ENUM_PLAY_STATE {stopped,playing,pausing};

// 计算比特率 计算压缩比
// 120 * 50 = 6000 字节 - 6500 字节 /s  6kB - 8 kB/s  8*6kbps  48kbps
// 1920 : 120  10倍以上
// speex  640 -> 76

#endif // AUDIOWORLD_H
