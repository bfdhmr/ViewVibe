#include "sdlaudioread.h"

SDLAudioRead::SDLAudioRead(QObject *parent) : QObject(parent)
{
    // 初始化 Opus 编码器和解码器
    int err;
    encoder = opus_encoder_create(48000, 1, OPUS_APPLICATION_VOIP, &err);

    // 设置音频规格
    SDL_AudioSpec desiredSpec;
    SDL_AudioSpec obtainedSpec;
    SDL_memset(&desiredSpec, 0, sizeof(desiredSpec));
    desiredSpec.freq = 48000; //采样率 48000Hz
    desiredSpec.format = AUDIO_S16LSB; //16 位 小端存储
    desiredSpec.channels = 1; //单声道
    desiredSpec.samples = 960; // 回调函数 每 960 个点 回调一次
    // 因为 1s 是 48000 点 那么 20ms 是 960 个点
    desiredSpec.callback = audioCallback; //回调函数
    desiredSpec.userdata = this; //回调函数传参
    //打开设备
    // 打开录音设备 第一个为空意味着 默认设备
    dev = SDL_OpenAudioDevice(NULL, 1, &desiredSpec, &obtainedSpec, 0);
    if (dev == 0) {
        qDebug() << "Failed to open audio device: " << SDL_GetError() ;
        SDL_Quit();
        return ;
    }
}

SDLAudioRead::~SDLAudioRead()
{
    //opus回收
    opus_encoder_destroy(encoder);

    // 停止采集音频
    SDL_PauseAudioDevice(dev, 1);
    // 关闭音频设备并清理
    SDL_CloseAudio();
    SDL_Quit();
}

void SDLAudioRead::slot_sendAudioFrame(QByteArray & bt)
{
    Q_EMIT SIG_sendAudioFrame(bt);
}

//音频回调函数 : 作用为将采集到的数据 编码发送, 此处稍后加编码
void SDLAudioRead::audioCallback(void *userdata, Uint8 *stream, int len)
{
    SDLAudioRead * audio = (SDLAudioRead *)userdata;
    if( len < 1920 ) return;

    //todo 静音检测
    if(0!=WebRtcVad_Process(audio->handle,48000,(int16_t*)stream,960))
    {
        //编码
        unsigned char opusData[4096];
        int nbBytes = opus_encode( audio->encoder, (const opus_int16*)( stream ),960, opusData,
                                   sizeof(opusData));
        if (nbBytes < 0) {
            qDebug() << "Opus encode error:" << opus_strerror(nbBytes);
            return;
        }
        //opus_encode 是编码函数 第一个参数是上面定义的编码器 , 第二个参数是要编码的缓冲区, 然后第三参数是采样点数, 然后第四参数是输出的缓冲区, 以及第五参数长度.

        //QByteArray sendBuffer( (char*) stream,len); // 使用原缓冲区 避免拷贝
        QByteArray sendBuffer( (char*) opusData,nbBytes);//发送编码之后的内容
        //编码并发送 注意是多线程. 此并非主线程.
        audio->slot_sendAudioFrame( sendBuffer );
        //采集编码之后的数据通过信号发送到主线程.
    }
    //静音，清零空间
    //memset((int16_t*)stream,0,320);

}

