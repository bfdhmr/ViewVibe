#include "clogic.h"
#include <string.h>
#include <stdio.h>
#include "block_epoll_net.h"

void CLogic::setNetPackMap()
{
    NetPackMap(_DEF_PACK_REGISTER_RQ)    = &CLogic::RegisterRq;
    NetPackMap(_DEF_PACK_LOGIN_RQ)       = &CLogic::LoginRq;
    NetPackMap(DEF_PACK_CREATEROOM_RQ)   = &CLogic::CreateRoomRq;
    NetPackMap(DEF_PACK_JOINROOM_RQ)     = &CLogic::JoinRoomRq;
    NetPackMap(DEF_PACK_LEAVEROOM_RQ)    = &CLogic::LeaveRoomRq;
    NetPackMap(DEF_PACK_AUDIO_FRAME)     = &CLogic::AudioFrameRq;
    NetPackMap(DEF_PACK_VIDEO_FRAME)     = &CLogic::VideoFrameRq;
    NetPackMap(DEF_PACK_AUDIO_REGISTER)  = &CLogic::AudioRegister;
    NetPackMap(DEF_PACK_VIDEO_REGISTER)  = &CLogic::VideoRegister;
    NetPackMap(_DEF_PACK_VIDEO_H264)     = &CLogic::VideoH264FrameRq;

}

#define _DEF_COUT_FUNC_    cout << "clientfd:"<< clientfd << __func__ << endl;

//注册
void CLogic::RegisterRq(sock_fd clientfd,char* szbuf,int nlen)
{
    _DEF_COUT_FUNC_
   //1.拆包
   STRU_REGISTER_RQ *rq=(STRU_REGISTER_RQ*)szbuf;
   STRU_REGISTER_RS rs;
   //获取tel password name
   std::string tel=rq->tel;
   std::string password=rq->password;
   std::string name=rq->name;
   //查表 t_user tel 有没有
   char sqlStr[1024]={0};
   sprintf(sqlStr,"select tel from t_user where tel='%s';",tel.c_str());
   list<string>resList;
   if(!m_sql->SelectMysql(sqlStr,1,resList))
   {
       printf("Select tel error\n");
       return;
   }
   if(resList.size()>0)//有 user存在
   {
       rs.result=tel_is_exist;
       m_tcp->SendData(clientfd,(char*)&rs,sizeof(rs));
       return;
   }
   resList.clear();
   //没有 name有没有
    sprintf(sqlStr,"select name from t_user where name='%s';",name.c_str());
    if(!m_sql->SelectMysql(sqlStr,1,resList))
    {
        printf("Select name error\n");
        return;
    }
   //有 name存在
    if(resList.size()>0)//有 user存在
    {
        rs.result=name_is_exist;
        m_tcp->SendData(clientfd,(char*)&rs,sizeof(rs));
        return;
    }
   //没有 写表 头像和签名和默认值 返回注册成功
   rs.result=register_success;
   sprintf(sqlStr,"insert into t_user(tel,password,name,icon,felling) values('%s','%s','%s','%d','%s');",rq->tel,rq->password,rq->name,1,"this is a text");
   if(!m_sql->UpdataMysql(sqlStr))
   {
       printf("Update Mysql error:%s \n",sqlStr);
       return;
   }
   m_tcp->SendData(clientfd,(char*)&rs,sizeof(rs));
}

//登录
void CLogic::LoginRq(sock_fd clientfd ,char* szbuf,int nlen)
{
            _DEF_COUT_FUNC_
            //拆包 手机号和密码
            STRU_LOGIN_RQ *rq=(STRU_LOGIN_RQ*)szbuf;
            std::string tel=rq->tel;
            std::string password=rq->password;
            char SqlBuf[128]={0};
            //根据tel 查pass和id 手机号
            sprintf(SqlBuf,"select password,id,name from t_user where tel='%s';",tel.c_str());
            list<string>Res;
            if(!m_sql->SelectMysql(SqlBuf,3,Res))
            {
                printf("select tel error\n");
                return;
            }
            STRU_LOGIN_RS rs;
            //查不到 返回 无此用户
            if(Res.empty())
            {
                rs.result=user_not_exist;
                m_tcp->SendData(clientfd,(char*)&rs,sizeof(rs));

                return;
            }
            //查到了 pass是否一致
            std:cout << rq->password << endl;
            //不一致，返回密码错
            if(strcmp(rq->password,Res.front().c_str())!=0)
            {
                rs.result=password_error;
                SendData( clientfd , (char*)&rs , sizeof(rs) );
                printf("password_error\n");
                return;
            }
            //一致 sock要保存起来 id->sock 映射
            Res.pop_front();
            int id=atoi(Res.front().c_str());
            Res.pop_front();
            UserInfo *pInfo=new UserInfo;
            pInfo->m_id=id;
            pInfo->m_roomid=0;
            pInfo->m_sockfd=clientfd;
            strcpy(pInfo->m_userName,Res.front().c_str());
            Res.pop_front();
            //判断id是否在线，在线就强制下线
            if(m_mapIDToUserInfo.IsExist(id))
            {
                //强制下线

            }
            m_mapIDToUserInfo.insert(pInfo->m_id,pInfo);
            rs.userid=id;
            rs.result=login_success;
            strcpy(rs.m_name,pInfo->m_userName);
            //写返回包 返回 带id和结果
            SendData( clientfd , (char*)&rs , sizeof(rs) );
}
//创建房间
void CLogic::CreateRoomRq(int clientfd, char *szbuf, int nlen)
{
    _DEF_COUT_FUNC_
    //拆包
    STRU_CREATEROOM_RQ* rq =(STRU_CREATEROOM_RQ*)szbuf;
    int roomid=0;
    //随机数得到房间，看有没有房间号，可能循环随机  map  roomid->list
    do{
        roomid=rand()%99999999+1;

    }while(m_mapIDToRoomid.IsExist(roomid));
    list <int> lst;
    lst.push_back(rq->m_UserID);
    m_mapIDToRoomid.insert(roomid,lst);
    printf("roomid is %d\n",roomid);
    //回复
    STRU_CREATEROOM_RS rs;
    rs.m_RoomId=roomid;
    rs.m_lResult=1;
    SendData(clientfd,(char*)&rs,sizeof(rs));
}
//加入房间
void CLogic::JoinRoomRq(int clientfd, char *szbuf, int nlen)
{
    _DEF_COUT_FUNC_
    //拆包
    STRU_JOINROOM_RQ* rq=(STRU_JOINROOM_RQ*)szbuf;
    STRU_JOINROOM_RS rs;
    //查看房间是否存在
    if(!m_mapIDToRoomid.IsExist(rq->m_RoomID))
    {
        rs.m_lResult=0;
        SendData(clientfd,(char*)&rs,sizeof(rs));
        return;
    }
    //不存在，返回失败
        rs.m_lResult=1;
        rs.m_RoomID=rq->m_RoomID;
        SendData(clientfd,(char*)&rs,sizeof(rs));
    //存在，返回成功

    if(!m_mapIDToUserInfo.IsExist(rq->m_UserID)) return;
    UserInfo *joiner ;
    m_mapIDToUserInfo.find(rq->m_UserID,joiner);
     STRU_ROOM_MEMBER_RQ joinrq;
     joinrq.m_UserID=rq->m_UserID;
    strcpy(joinrq.m_szUser,joiner->m_userName);
    //给自己用于更新自己的信息
     SendData(clientfd,(char*)&joinrq,sizeof(joinrq));
    //根据房间号拿到房间成员列表
    list <int>lst;
    m_mapIDToRoomid.find(rq->m_RoomID,lst);
    //遍历列表，把加入人的信息发给每一个房间内成员
    for(auto ite=lst.begin();ite!=lst.end();++ite)
    {
        int id=*ite;
       if( !m_mapIDToUserInfo.IsExist(id))
       {
           continue;
       }
      UserInfo*memInfo;
      m_mapIDToUserInfo.find(id,memInfo);
      STRU_ROOM_MEMBER_RQ memrq;
      memrq.m_UserID=memInfo->m_id;
      strcpy(memrq.m_szUser,memInfo->m_userName);
      SendData(memInfo->m_sockfd,(char*)&joinrq,sizeof (joinrq));
      //房间内成员每个人信息发给加入人
      SendData(clientfd,(char*)&memrq,sizeof(memrq));
    }


    //加入人 添加到房间列表
    lst.push_back(rq->m_UserID);
    m_mapIDToRoomid.insert(rq->m_RoomID,lst);
}

void CLogic::LeaveRoomRq(int clientfd, char *szbuf, int nlen)
{
    //拆包
    STRU_LEAVEROOM_RQ *rq=(STRU_LEAVEROOM_RQ*)szbuf;
    //看房间是否存在，如果房间存在，获得用户列表
    if(!m_mapIDToRoomid.IsExist(rq->m_RoomId))
    {
        return;
    }
    list<int> lst;
    m_mapIDToRoomid.find(rq->m_RoomId,lst);
    //遍历每个用户，用户是否在线，在线转发
    for(auto ite=lst.begin();ite!=lst.end();)
    {
        int userid=*ite;
         //是不是自己，如果是自己 从列表中去除 --从房间中移除了
        if(userid==rq->m_nUserId)
        {
            ite=lst.erase(ite);
        }
        else{
            //用户是否在线,在线转发
            if(m_mapIDToUserInfo.IsExist(userid)){
                UserInfo*info;
                m_mapIDToUserInfo.find(userid,info);
                SendData(info->m_sockfd,szbuf,nlen);
            }
            ++ite;
        }
    }



    //列表是否节点数为0->map项去掉
    if(lst.size()==0)
    {
        m_mapIDToRoomid.erase(rq->m_RoomId);
        return;
    }
    //更新房间成员列表
    m_mapIDToRoomid.insert(rq->m_RoomId,lst);

}
//音频数据帧
//int type
//int userid
//int roomid
//int min
//int sec
//int msec
//QByteArray audioFrame
void CLogic::AudioFrameRq(int clientfd, char *szbuf, int nlen)
{
    //_DEF_COUT_FUNC_
            //拆包
            char *tmp=szbuf;
            //跳过type
            tmp+=sizeof(int);
            int userid=*(int*)tmp;
            //跳过userid
            tmp+=sizeof(int);
            int roomid=*(int*)tmp;
            //判断房间是否存在
            if(!m_mapIDToRoomid.IsExist(roomid)) return;
            //获取成员列表
            list<int> lst;
            m_mapIDToRoomid.find(roomid,lst);
            //转发
            for(auto i=lst.begin();i!=lst.end();++i)
            {
                if(!m_mapIDToUserInfo.IsExist(*i)) continue;
                if(*i==userid) continue;
                UserInfo* userid;
                m_mapIDToUserInfo.find(*i,userid);
                //SendData(userid->m_sockfd,szbuf,nlen);
                SendData(userid->m_audiofd,szbuf,nlen);
            }

}

void CLogic::VideoFrameRq(int clientfd, char *szbuf, int nlen)
{

             //_DEF_COUT_FUNC_
            //拆包
            char *tmp=szbuf;
            //跳过type
            tmp+=sizeof(int);
            int userid=*(int*)tmp;
            //跳过userid
            tmp+=sizeof(int);
            int roomid=*(int*)tmp;
            //判断房间是否存在
            if(!m_mapIDToRoomid.IsExist(roomid)) return;
            //获取成员列表
            list<int> lst;
            m_mapIDToRoomid.find(roomid,lst);
            //转发
            for(auto i=lst.begin();i!=lst.end();++i)
            {
                if(!m_mapIDToUserInfo.IsExist(*i)) continue;
                if(*i==userid) continue;
                UserInfo* userid;
                m_mapIDToUserInfo.find(*i,userid);
                //SendData(userid->m_sockfd,szbuf,nlen);
                SendData(userid->m_videofd,szbuf,nlen);
            }

}

void CLogic::AudioRegister(int clientfd, char *szbuf, int nlen)
{
    printf("clientfd:%d AduioRegister\n",clientfd);
    //拆包
    STRU_AUDIO_REGISTER *rq=(STRU_AUDIO_REGISTER *) szbuf;
    int userid=rq->m_userid;
    //根据userid 找到节点 更新fd
    if(m_mapIDToUserInfo.IsExist(userid))
    {
        UserInfo *user;
        m_mapIDToUserInfo.find(userid,user);
        user->m_audiofd=clientfd;
    }

}

void CLogic::VideoRegister(int clientfd, char *szbuf, int nlen)
{
    printf("clientfd:%d VideoRegister\n",clientfd);
    //拆包
    STRU_VIDEO_REGISTER *rq=(STRU_VIDEO_REGISTER *) szbuf;
    int userid=rq->m_userid;
    //根据userid 找到节点 更新fd
    if(m_mapIDToUserInfo.IsExist(userid))
    {
        UserInfo *user;
        m_mapIDToUserInfo.find(userid,user);
        user->m_videofd=clientfd;
    }
}

void CLogic::VideoH264FrameRq(sock_fd clientfd, char *szbuf, int nlen)
{
    cout << "clientfd:" << clientfd << __func__ << endl;

    // 拆包
    char* tmp = szbuf;
    // 跳过type
    tmp += sizeof(int);
    int uid = *(int*)tmp;
    // 跳过userid
    tmp += sizeof(int);
    // 获取roomid
    int roomid = *(int*)tmp;

    // 看房间是否存在
    if(!m_mapIDToRoomid.IsExist(roomid)) return;

    list<int> lst;
    m_mapIDToRoomid.find(roomid,lst);
    // 获取成员列表
    for(auto ite = lst.begin(); ite != lst.end(); ++ite)
    {
        // 看是否在线 转发
        int userid = *ite;
        // 屏蔽掉自己 不转发
        if(uid == userid) continue;

        if(!m_mapIDToUserInfo.IsExist(userid)) continue;
        UserInfo *userinfo;
        m_mapIDToUserInfo.find(userid,userinfo);

        // 原样转发H.264视频帧
        SendData(userinfo->m_videofd, szbuf, nlen);
    }
}
